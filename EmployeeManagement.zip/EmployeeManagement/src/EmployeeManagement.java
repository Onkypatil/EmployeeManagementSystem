import java.sql.*;
import javax.swing.*;
public class EmployeeManagement {
	public static Connection ConnectDB() {
		try {
			Class.forName("org.sqlite.JDBC");
			Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\ONKAR\\eclipse-java-2020-06-R-win32-x86_64\\Employee.db");
			JOptionPane.showMessageDialog(null,"Connection Made");
			return conn;
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,"Connection Error");
			return null;
		}
	}
	
	
		
	

}
