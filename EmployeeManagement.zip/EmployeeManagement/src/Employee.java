import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import java.awt.event.ActionEvent;
import java.sql.*;
public class Employee {

	private JFrame frame;
	private JTextField jtxtEmployeeID;
	private JTable table;
	private JTextField jtxtFirstName;
	private JTextField jtxtSurname;
	private JTextField jtxtGender;
	private JTextField jtxtDOB;
	private JTextField jtxtAge;
	private JTextField jtxtSalary;
	
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	DefaultTableModel model = new DefaultTableModel();
	

	/**
	 * Launch the application.
	 */
	
	@SuppressWarnings("null")
	public void updateTable()
	{
		conn = EmployeeManagement.ConnectDB();
		if (conn != null) {
			String sql = "EmployeeId, FirstName, Surname, Gender, DOB, Age, Salary";
			try {
				pst = conn.prepareStatement(sql);
				rs = pst.executeQuery();
				@SuppressWarnings("unused")
				Object[] columnDates = new Object[7];
				while (rs.next()) {
					String[] columnData = null;
					columnData [0] = rs.getString("EmpID");
					columnData [1] = rs.getString("FirstName");
					columnData [2] = rs.getString("Surname");
					columnData [3] = rs.getString("Gender");
					columnData [4] = rs.getString("DOB");
					columnData [5] = rs.getString("Age");
					columnData [6] = rs.getString("Salary");
					
					model.addRow(columnData);
					
					
				}
			}
			catch(Exception e) {
				JOptionPane.showMessageDialog(null, e);
				
				
			}
		} 
			
			
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Employee window = new Employee();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Employee() {
		initialize();
		conn = EmployeeManagement.ConnectDB();
		Object col[] = {"EmployeeId", "FirstName", "Surname", "Gender", "DOB", "Age", "Salary"};
		model.setColumnIdentifiers(col);
	}
		
		

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0,0, 1500, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("EmployeeID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(48, 52, 190, 36);
		frame.getContentPane().add(lblNewLabel);
		
		jtxtEmployeeID = new JTextField();
		jtxtEmployeeID.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtEmployeeID.setBounds(309, 49, 246, 43);
		frame.getContentPane().add(jtxtEmployeeID);
		jtxtEmployeeID.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(611, 188, 749, 552);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"EmpID", "FirstName", "Surname", "Gender", "DOB", "Age", "Salary"
			}
		));
		table.setFont(new Font("Tahoma", Font.BOLD, 14));
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("NewEntry");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				@SuppressWarnings("unused")
				String sql = "INSERT INTO employee (EmpID, FirstName, Surname, Gender, DOB, Age, Salary)VALUES(?,?,?,?,?,?,?)";
				
				try {
					pst = conn.prepareStatement(sql);
					pst.setString(1, jtxtEmployeeID.getText());
					pst.setString(2, jtxtFirstName.getText());
					pst.setString(3, jtxtSurname.getText());
					pst.setString(4, jtxtGender.getText());
					pst.setString(5, jtxtDOB.getText());
					pst.setString(6, jtxtAge.getText());
					pst.setString(7, jtxtSalary.getText());
					
					pst.execute();
					rs.close();
					pst.close();
					
				}
				catch(Exception ev)
				{
					JOptionPane.showMessageDialog(null, "System Update Complete");
				}
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.addRow(new Object[] {
						jtxtEmployeeID.getText(),
						 jtxtFirstName.getText(),
						 jtxtSurname.getText(),
						 jtxtGender.getText(),
						 jtxtDOB.getText(),
						 jtxtAge.getText(),
					 jtxtSalary.getText(),
						
				}
						);
				if(table.getSelectedRow() == -1) {
					if(table.getRowCount() == 0) {
						JOptionPane.showMessageDialog(null, "Memership COnfirmed","Employee DB system",
						JOptionPane.OK_OPTION);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(611, 82, 167, 36);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("FirstName");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(48, 114, 190, 36);
		frame.getContentPane().add(lblNewLabel_1);
		
		jtxtFirstName = new JTextField();
		jtxtFirstName.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtFirstName.setColumns(10);
		jtxtFirstName.setBounds(309, 111, 246, 43);
		frame.getContentPane().add(jtxtFirstName);
		
		JLabel lblNewLabel_2 = new JLabel("Surname");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(48, 181, 190, 36);
		frame.getContentPane().add(lblNewLabel_2);
		
		jtxtSurname = new JTextField();
		jtxtSurname.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtSurname.setColumns(10);
		jtxtSurname.setBounds(309, 178, 246, 43);
		frame.getContentPane().add(jtxtSurname);
		
		JLabel lblNewLabel_3 = new JLabel("Gender");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(48, 250, 190, 36);
		frame.getContentPane().add(lblNewLabel_3);
		
		jtxtGender = new JTextField();
		jtxtGender.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtGender.setColumns(10);
		jtxtGender.setBounds(309, 247, 246, 43);
		frame.getContentPane().add(jtxtGender);
		
		JLabel lblNewLabel_4 = new JLabel("DOB");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_4.setBounds(48, 317, 190, 36);
		frame.getContentPane().add(lblNewLabel_4);
		
		jtxtDOB = new JTextField();
		jtxtDOB.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtDOB.setColumns(10);
		jtxtDOB.setBounds(309, 314, 246, 43);
		frame.getContentPane().add(jtxtDOB);
		
		JLabel lblNewLabel_5 = new JLabel("Age");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_5.setBounds(48, 383, 190, 36);
		frame.getContentPane().add(lblNewLabel_5);
		
		jtxtAge = new JTextField();
		jtxtAge.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtAge.setColumns(10);
		jtxtAge.setBounds(309, 380, 246, 43);
		frame.getContentPane().add(jtxtAge);
		
		JLabel lblSalary = new JLabel("Salary");
		lblSalary.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSalary.setBounds(48, 450, 190, 36);
		frame.getContentPane().add(lblSalary);
		
		jtxtSalary = new JTextField();
		jtxtSalary.setFont(new Font("Tahoma", Font.BOLD, 18));
		jtxtSalary.setColumns(10);
		jtxtSalary.setBounds(309, 447, 246, 43);
		frame.getContentPane().add(jtxtSalary);
		
		JButton btnUpdateprint = new JButton("Update/Print");
		btnUpdateprint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MessageFormat header = new MessageFormat("Printing");
				MessageFormat footer = new MessageFormat("page {0, number, integer}");
				
				try {
					table.print();
					
				}
				catch(java.awt.print.PrinterException ev) {
					System.err.format("No Printing", ev.getMessage());
				} 
				
			}
		});
		btnUpdateprint.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnUpdateprint.setBounds(814, 82, 167, 36);
		frame.getContentPane().add(btnUpdateprint);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtxtEmployeeID.setText(null);
				jtxtFirstName.setText(null);
				jtxtSurname.setText(null);
				jtxtGender.setText(null);
				jtxtDOB.setText(null);
				jtxtAge.setText(null);
				jtxtSalary.setText(null);
			}
				
		}
			);
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnReset.setBounds(1005, 82, 167, 36);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame = new JFrame("Exit");
					if(JOptionPane.showConfirmDialog(frame, "Confirm Exit?", "Employee DB System",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
						System.exit(0);
					}
				
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnExit.setBounds(1202, 82, 167, 36);
		frame.getContentPane().add(btnExit);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.setBounds(611, 141, 167, 36);
		frame.getContentPane().add(btnNewButton_1);
	}
}
